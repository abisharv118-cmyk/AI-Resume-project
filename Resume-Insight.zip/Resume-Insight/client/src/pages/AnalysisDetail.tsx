import { useMemo, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { ArrowLeft, Trash2 } from "lucide-react";
import AppShell from "@/components/AppShell";
import ScoreBadge from "@/components/ScoreBadge";
import AnalysisResultBlocks from "@/components/AnalysisResultBlocks";
import ConfirmDialog from "@/components/ConfirmDialog";
import CopyButton from "@/components/CopyButton";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useDeleteResumeAnalysis, useResumeAnalysis } from "@/hooks/use-resume-analyses";

function parseId(param: string | undefined) {
  const n = Number(param);
  return Number.isFinite(n) ? n : NaN;
}

export default function AnalysisDetail() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/analyses/:id");
  const id = parseId(params?.id);

  const { data, isLoading, error } = useResumeAnalysis(id);
  const del = useDeleteResumeAnalysis();

  const [confirmOpen, setConfirmOpen] = useState(false);

  const headerCopy = useMemo(() => {
    if (!data) return "";
    const lines: string[] = [];
    lines.push(`Name: ${data.name}`);
    if (data.targetRole) lines.push(`Target role: ${data.targetRole}`);
    lines.push(`Overall score: ${data.result.overallScore}/100`);
    lines.push("");
    lines.push("Summary:");
    lines.push(data.result.summary);
    lines.push("");
    lines.push("Strengths:");
    lines.push(...(data.result.strengths ?? []).map((s) => `- ${s}`));
    lines.push("");
    lines.push("Gaps:");
    lines.push(...(data.result.gaps ?? []).map((s) => `- ${s}`));
    lines.push("");
    lines.push("ATS keywords:");
    lines.push((data.result.atsKeywords ?? []).join(", "));
    lines.push("");
    lines.push("Red flags:");
    lines.push(...(data.result.redFlags ?? []).map((s) => `- ${s}`));
    return lines.join("\n");
  }, [data]);

  return (
    <AppShell
      title={data ? `Resume Lens — ${data.name}` : "Resume Lens — Analysis"}
      description="Detailed AI resume analysis report: score, summary, strengths, gaps, ATS keywords, rewrite suggestions, and red flags."
    >
      <header className="flex flex-col gap-4">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Link
                href="/"
                className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors ring-focus rounded-xl px-2 py-1"
                data-testid="back-dashboard"
              >
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Link>
            </div>

            <h1
              className="mt-2 font-display text-3xl sm:text-4xl leading-tight truncate"
              data-testid="detail-title"
            >
              {isLoading ? "Loading…" : data?.name ?? "Analysis"}
            </h1>

            {data ? (
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed" data-testid="detail-subtitle">
                {data.targetRole ? (
                  <>
                    Target role: <span className="text-foreground/90 font-medium">{data.targetRole}</span>
                  </>
                ) : (
                  <>Target role: <span className="italic">not specified</span></>
                )}
              </p>
            ) : null}
          </div>

          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            {data ? (
              <ScoreBadge
                score={data.result.overallScore}
                size="lg"
                data-testid="detail-score"
              />
            ) : null}

            <CopyButton
              text={headerCopy}
              label="Copy report"
              data-testid="copy-report"
              variant="outline"
            />

            <Button
              type="button"
              variant="outline"
              className="rounded-2xl ring-focus hover:bg-destructive/8 hover:text-destructive hover:border-destructive/30 transition-all"
              onClick={() => setConfirmOpen(true)}
              disabled={!data || del.isPending}
              data-testid="btn-delete-from-detail"
            >
              <Trash2 className="h-4 w-4" />
              <span className="ml-2">{del.isPending ? "Deleting…" : "Delete"}</span>
            </Button>
          </div>
        </div>
      </header>

      <Separator className="my-6" />

      {isLoading ? (
        <div className="space-y-4" data-testid="detail-loading">
          <div className="rounded-3xl border bg-card/60 p-6 shadow-sm">
            <Skeleton className="h-6 w-56 skeleton-shimmer rounded-xl" />
            <Skeleton className="mt-3 h-4 w-full skeleton-shimmer rounded-xl" />
            <Skeleton className="mt-2 h-4 w-[85%] skeleton-shimmer rounded-xl" />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="rounded-3xl border bg-card/60 p-6 shadow-sm">
                <Skeleton className="h-5 w-44 skeleton-shimmer rounded-xl" />
                <Skeleton className="mt-3 h-4 w-full skeleton-shimmer rounded-xl" />
                <Skeleton className="mt-2 h-4 w-[78%] skeleton-shimmer rounded-xl" />
              </div>
            ))}
          </div>
        </div>
      ) : error ? (
        <div className="rounded-3xl border bg-destructive/8 p-6 shadow-sm" data-testid="detail-error">
          <div className="font-display text-2xl">Couldn’t load this analysis</div>
          <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
            {(error as Error).message}
          </p>
        </div>
      ) : !data ? (
        <div className="rounded-3xl border bg-muted/60 p-8 text-center shadow-sm" data-testid="detail-not-found">
          <div className="font-display text-2xl">Not found</div>
          <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
            This analysis may have been deleted.
          </p>
          <div className="mt-5">
            <Button
              type="button"
              className="rounded-2xl"
              onClick={() => navigate("/")}
              data-testid="go-dashboard"
            >
              Back to dashboard
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          <div className="rounded-3xl border bg-gradient-to-br from-primary/10 via-card/60 to-accent/8 p-6 shadow-sm" data-testid="detail-hero">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
              <div className="max-w-2xl">
                <div className="text-xs font-semibold text-muted-foreground">
                  Recruiter-style verdict
                </div>
                <div className="mt-2 text-sm leading-relaxed whitespace-pre-wrap" data-testid="detail-summary">
                  {data.result.summary}
                </div>
              </div>
              <div className="shrink-0">
                <ScoreBadge score={data.result.overallScore} size="lg" />
              </div>
            </div>
          </div>

          <AnalysisResultBlocks result={data.result} />
        </div>
      )}

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Delete this analysis?"
        description="This removes the saved report. You can always run a new analysis later."
        confirmLabel={del.isPending ? "Deleting…" : "Delete"}
        onConfirm={() => {
          if (!data) return;
          del.mutate(data.id, {
            onSuccess: () => {
              toast({ title: "Deleted", description: "Analysis removed." });
              setConfirmOpen(false);
              navigate("/");
            },
            onError: (e) => {
              toast({
                title: "Delete failed",
                description: (e as Error).message,
                variant: "destructive",
              });
            },
          });
        }}
        confirmTestId="confirm-delete-detail"
        cancelTestId="cancel-delete-detail"
      />
    </AppShell>
  );
}
