import { useMemo, useState } from "react";
import { Link } from "wouter";
import {
  ArrowUpRight,
  Calendar,
  FileSearch,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import AppShell from "@/components/AppShell";
import MetricCard from "@/components/MetricCard";
import ScoreBadge from "@/components/ScoreBadge";
import ConfirmDialog from "@/components/ConfirmDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  useDeleteResumeAnalysis,
  useResumeAnalyses,
  type ResumeAnalysisClient,
} from "@/hooks/use-resume-analyses";
import { cn } from "@/lib/utils";

function formatDate(d: Date) {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "2-digit",
    year: "numeric",
  }).format(d);
}

export default function Dashboard() {
  const { toast } = useToast();
  const { data, isLoading, error } = useResumeAnalyses();
  const del = useDeleteResumeAnalysis();

  const [query, setQuery] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<number | null>(null);

  const items = (data ?? []) as ResumeAnalysisClient[];

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter((a) => {
      const score = a.result?.overallScore ?? 0;
      return (
        a.name.toLowerCase().includes(q) ||
        (a.targetRole ?? "").toLowerCase().includes(q) ||
        String(score).includes(q)
      );
    });
  }, [items, query]);

  const avg = useMemo(() => {
    if (!items.length) return 0;
    const sum = items.reduce((acc, it) => acc + (it.result?.overallScore ?? 0), 0);
    return Math.round(sum / items.length);
  }, [items]);

  return (
    <AppShell
      title="Resume Lens — Dashboard"
      description="Recruiter-style dashboard of your AI resume analyses. Review scores, spot gaps, and refine fast."
    >
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl sm:text-4xl leading-tight text-balance">
            Analysis dashboard
          </h1>
          <p className="mt-2 text-base text-muted-foreground leading-relaxed">
            A clean history of every run — scores, context, and the fastest path to a stronger resume.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/new"
            className={cn(
              "inline-flex items-center justify-center gap-2",
              "px-4 py-2.5 rounded-2xl font-semibold",
              "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground",
              "shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/25 hover:-translate-y-0.5",
              "active:translate-y-0 active:shadow-md transition-all duration-200",
              "ring-focus",
            )}
            data-testid="cta-new-analysis"
          >
            <Plus className="h-4 w-4" />
            New analysis
          </Link>
        </div>
      </header>

      <Separator className="my-6" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <MetricCard
          label="Total analyses"
          value={items.length}
          hint="Your iteration history — keep refining."
          icon={<FileSearch className="h-5 w-5 text-primary" />}
          tone="primary"
          data-testid="metric-total"
        />
        <MetricCard
          label="Average score"
          value={`${avg}`}
          hint="Aim for 80+ for competitive roles."
          icon={<ArrowUpRight className="h-5 w-5 text-accent" />}
          tone="accent"
          data-testid="metric-average"
        />
        <MetricCard
          label="Last run"
          value={items[0]?.createdAt ? formatDate(items[0].createdAt) : "—"}
          hint="Freshness matters in hiring cycles."
          icon={<Calendar className="h-5 w-5 text-foreground" />}
          tone="muted"
          data-testid="metric-last-run"
        />
      </div>

      <div className="mt-6 flex flex-col md:flex-row md:items-center gap-3 md:gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, target role, or score…"
            className="pl-9 h-11 rounded-2xl bg-background/60 border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all"
            type="search"
            data-testid="search-analyses"
          />
        </div>
        <Button
          type="button"
          variant="secondary"
          className="h-11 rounded-2xl ring-focus"
          onClick={() => setQuery("")}
          data-testid="clear-search"
        >
          Clear
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <div className="grid grid-cols-1 gap-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className="rounded-3xl border bg-card/60 p-5 shadow-sm"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-2 w-full">
                    <Skeleton className="h-5 w-44 skeleton-shimmer rounded-xl" />
                    <Skeleton className="h-4 w-64 skeleton-shimmer rounded-xl" />
                  </div>
                  <Skeleton className="h-8 w-20 skeleton-shimmer rounded-2xl" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div
            className="rounded-3xl border bg-destructive/8 p-6 shadow-sm"
            data-testid="error-state"
          >
            <div className="font-display text-xl">Couldn’t load your dashboard</div>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
              {(error as Error).message}
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div
            className="grain rounded-3xl border bg-gradient-to-br from-muted/60 to-background/70 p-10 text-center shadow-sm"
            data-testid="empty-state"
          >
            <div className="mx-auto h-14 w-14 rounded-3xl border bg-background/60 shadow-sm flex items-center justify-center">
              <FileSearch className="h-6 w-6 text-primary" />
            </div>
            <h2 className="mt-4 font-display text-2xl">No analyses yet</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
              Run your first analysis — get an overall score, ATS keywords, and rewrite suggestions.
            </p>
            <div className="mt-6 flex items-center justify-center">
              <Link
                href="/new"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl font-semibold bg-gradient-to-r from-primary to-primary/85 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all ring-focus"
                data-testid="empty-new-analysis"
              >
                <Plus className="h-4 w-4" />
                New analysis
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4" data-testid="analyses-list">
            {filtered.map((a) => (
              <div
                key={a.id}
                className={cn(
                  "group grain rounded-3xl border bg-card/60 shadow-sm overflow-hidden",
                  "hover:shadow-md hover:-translate-y-[1px] transition-all duration-200",
                )}
                data-testid={`analysis-row-${a.id}`}
              >
                <div className="p-5 sm:p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-3 flex-wrap">
                      <div className="font-display text-xl leading-tight truncate">
                        {a.name}
                      </div>
                      <ScoreBadge
                        score={a.result?.overallScore ?? 0}
                        size="sm"
                        data-testid={`analysis-score-${a.id}`}
                      />
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground leading-relaxed">
                      {a.targetRole ? (
                        <span data-testid={`analysis-targetRole-${a.id}`}>
                          Target role: <span className="text-foreground/90 font-medium">{a.targetRole}</span>
                        </span>
                      ) : (
                        <span data-testid={`analysis-targetRole-${a.id}`}>
                          Target role: <span className="italic">not specified</span>
                        </span>
                      )}
                      <span className="mx-2 text-muted-foreground/60">•</span>
                      <span data-testid={`analysis-createdAt-${a.id}`}>
                        {formatDate(a.createdAt)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Link
                      href={`/analyses/${a.id}`}
                      className={cn(
                        "inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl font-semibold",
                        "bg-gradient-to-r from-accent to-accent/80 text-accent-foreground",
                        "shadow-md shadow-accent/15 hover:shadow-lg hover:shadow-accent/20 hover:-translate-y-0.5",
                        "active:translate-y-0 transition-all ring-focus",
                      )}
                      data-testid={`view-analysis-${a.id}`}
                    >
                      View
                      <ArrowUpRight className="h-4 w-4" />
                    </Link>

                    <Button
                      type="button"
                      variant="outline"
                      className="rounded-2xl ring-focus hover:bg-destructive/8 hover:text-destructive hover:border-destructive/30 transition-all"
                      onClick={() => {
                        setPendingDeleteId(a.id);
                        setConfirmOpen(true);
                      }}
                      data-testid={`delete-analysis-${a.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="h-1 bg-gradient-to-r from-primary/35 via-accent/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Delete analysis?"
        description="This removes the saved analysis and its results. This action can’t be undone."
        confirmLabel={del.isPending ? "Deleting…" : "Delete"}
        onConfirm={() => {
          if (!pendingDeleteId) return;
          del.mutate(pendingDeleteId, {
            onSuccess: () => {
              toast({ title: "Deleted", description: "Analysis removed." });
              setConfirmOpen(false);
              setPendingDeleteId(null);
            },
            onError: (e) => {
              toast({
                title: "Delete failed",
                description: (e as Error).message,
                variant: "destructive",
              });
            },
          });
        }}
        confirmTestId="confirm-delete"
        cancelTestId="cancel-delete"
      />
    </AppShell>
  );
}
