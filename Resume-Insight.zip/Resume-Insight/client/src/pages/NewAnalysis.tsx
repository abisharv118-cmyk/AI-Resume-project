import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { Wand2 } from "lucide-react";
import AppShell from "@/components/AppShell";
import ScoreBadge from "@/components/ScoreBadge";
import AnalysisResultBlocks from "@/components/AnalysisResultBlocks";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  useAnalyzeResume,
  useCreateResumeAnalysis,
} from "@/hooks/use-resume-analyses";
import type { CreateResumeAnalysisRequest, ResumeAnalysisResult } from "@shared/schema";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  targetRole: z.string().optional(),
  resumeText: z.string().min(50, "Resume text must be at least 50 characters"),
  jobDescription: z.string().optional(),
});

export default function NewAnalysis() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const analyze = useAnalyzeResume();
  const create = useCreateResumeAnalysis();

  const [name, setName] = useState("");
  const [targetRole, setTargetRole] = useState("");
  const [resumeText, setResumeText] = useState("");
  const [jobDescription, setJobDescription] = useState("");

  const [preview, setPreview] = useState<ResumeAnalysisResult | null>(null);

  const payload: CreateResumeAnalysisRequest = useMemo(
    () => ({
      name,
      targetRole: targetRole.trim() ? targetRole.trim() : undefined,
      resumeText,
      jobDescription: jobDescription.trim() ? jobDescription.trim() : undefined,
    }),
    [name, targetRole, resumeText, jobDescription],
  );

  const isBusy = analyze.isPending || create.isPending;

  async function run() {
    const parsed = formSchema.safeParse(payload);
    if (!parsed.success) {
      const msg = parsed.error.issues[0]?.message ?? "Invalid input";
      toast({ title: "Fix the form", description: msg, variant: "destructive" });
      return;
    }

    try {
      // 1) AI analyze
      const result = await analyze.mutateAsync(parsed.data);

      // 2) Persist analysis + result
      const created = await create.mutateAsync({
        ...parsed.data,
        result,
      });

      toast({
        title: "Analysis saved",
        description: "Opening the full report…",
      });

      navigate(`/analyses/${created.id}`);
    } catch (e) {
      toast({
        title: "Analysis failed",
        description: (e as Error).message,
        variant: "destructive",
      });
    }
  }

  async function previewOnly() {
    const parsed = formSchema.safeParse(payload);
    if (!parsed.success) {
      const msg = parsed.error.issues[0]?.message ?? "Invalid input";
      toast({ title: "Fix the form", description: msg, variant: "destructive" });
      return;
    }

    try {
      const result = await analyze.mutateAsync(parsed.data);
      setPreview(result);
      toast({ title: "Preview ready", description: "Review results, then save." });
    } catch (e) {
      toast({
        title: "Preview failed",
        description: (e as Error).message,
        variant: "destructive",
      });
    }
  }

  return (
    <AppShell
      title="Resume Lens — New analysis"
      description="Create a new AI resume analysis. Paste resume text and optional job description for ATS-aligned insights."
    >
      <header className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl sm:text-4xl leading-tight text-balance">
            New analysis
          </h1>
          <p className="mt-2 text-base text-muted-foreground leading-relaxed">
            Paste a resume (plain text) and optionally the job description. You’ll get a score,
            strengths, gaps, ATS keywords, and rewrite suggestions.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            type="button"
            variant="secondary"
            className="rounded-2xl h-11 ring-focus"
            onClick={previewOnly}
            disabled={isBusy}
            data-testid="btn-preview"
          >
            {analyze.isPending ? "Analyzing…" : "Preview (AI only)"}
          </Button>

          <Button
            type="button"
            className="rounded-2xl h-11 px-5 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all ring-focus"
            onClick={run}
            disabled={isBusy}
            data-testid="btn-run-analysis"
          >
            <Wand2 className="h-4 w-4 mr-2" />
            {create.isPending ? "Saving…" : analyze.isPending ? "Analyzing…" : "Analyze & Save"}
          </Button>
        </div>
      </header>

      <Separator className="my-6" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:gap-8">
        <div className="space-y-4">
          <div className="rounded-3xl border bg-card/60 shadow-sm p-5 sm:p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-semibold" htmlFor="name">
                  Candidate name
                </label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Jordan Lee"
                  className="mt-2 h-11 rounded-2xl bg-background/60 border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all"
                  data-testid="field-name"
                />
              </div>
              <div>
                <label className="text-sm font-semibold" htmlFor="targetRole">
                  Target role (optional)
                </label>
                <Input
                  id="targetRole"
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value)}
                  placeholder="e.g., Product Manager"
                  className="mt-2 h-11 rounded-2xl bg-background/60 border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all"
                  data-testid="field-targetRole"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="text-sm font-semibold" htmlFor="resumeText">
                Resume text
              </label>
              <Textarea
                id="resumeText"
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                placeholder="Paste your resume here (plain text). Include impact bullets, metrics, tools, and role scope."
                className="mt-2 min-h-[220px] rounded-2xl bg-background/60 border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all leading-relaxed"
                data-testid="field-resumeText"
              />
              <div className="mt-2 text-xs text-muted-foreground" data-testid="resume-length">
                {resumeText.length} characters (min 50)
              </div>
            </div>

            <div className="mt-4">
              <label className="text-sm font-semibold" htmlFor="jobDescription">
                Job description (optional)
              </label>
              <Textarea
                id="jobDescription"
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                placeholder="Paste the JD to identify missing keywords and responsibilities."
                className="mt-2 min-h-[160px] rounded-2xl bg-background/60 border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all leading-relaxed"
                data-testid="field-jobDescription"
              />
            </div>
          </div>

          <div className="rounded-3xl border bg-gradient-to-br from-muted/70 to-background/70 p-5 sm:p-6 shadow-sm">
            <div className="font-display text-xl">What you’ll get</div>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground leading-relaxed">
              <li>• Overall score (0–100) with recruiter-style summary</li>
              <li>• Strengths to keep, gaps to close, and red flags to address</li>
              <li>• ATS keyword list for targeted roles</li>
              <li>• Rewrite suggestions with clear “why”</li>
            </ul>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-3xl border bg-card/60 shadow-sm p-5 sm:p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-display text-2xl">Live preview</div>
                <p className="mt-1 text-sm text-muted-foreground leading-relaxed">
                  Run “Preview” for an AI-only report (not saved). Use “Analyze & Save” to store it.
                </p>
              </div>
              {preview ? (
                <ScoreBadge
                  score={preview.overallScore}
                  size="lg"
                  data-testid="preview-score"
                />
              ) : null}
            </div>

            <Separator className="my-4" />

            {!preview ? (
              <div className="text-sm text-muted-foreground leading-relaxed" data-testid="preview-empty">
                No preview yet. Fill the form and click <span className="font-semibold text-foreground">Preview</span>.
              </div>
            ) : (
              <div className="space-y-4">
                <div className="rounded-3xl border bg-gradient-to-br from-primary/8 to-accent/6 p-4">
                  <div className="text-xs font-semibold text-muted-foreground">Summary</div>
                  <div className="mt-2 text-sm leading-relaxed whitespace-pre-wrap" data-testid="preview-summary">
                    {preview.summary}
                  </div>
                </div>

                <AnalysisResultBlocks result={preview} />
              </div>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
