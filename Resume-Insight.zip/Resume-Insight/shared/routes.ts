import { z } from "zod";
import {
  insertResumeAnalysisSchema,
  resumeAnalysisResultSchema,
  type ResumeAnalysisResponse,
} from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  resumeAnalyses: {
    list: {
      method: "GET" as const,
      path: "/api/resume-analyses",
      responses: {
        200: z.array(z.custom<ResumeAnalysisResponse>()),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/resume-analyses/:id",
      responses: {
        200: z.custom<ResumeAnalysisResponse>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/resume-analyses",
      input: insertResumeAnalysisSchema,
      responses: {
        201: z.custom<ResumeAnalysisResponse>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/resume-analyses/:id",
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  ai: {
    analyzeResume: {
      method: "POST" as const,
      path: "/api/ai/analyze-resume",
      input: insertResumeAnalysisSchema,
      responses: {
        200: resumeAnalysisResultSchema,
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(
  path: string,
  params?: Record<string, string | number>
): string {
  let url = path;
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      url = url.replace(`:${key}`, String(value));
    }
  }
  return url;
}

export type CreateResumeAnalysisInput = z.infer<
  typeof api.resumeAnalyses.create.input
>;
export type ResumeAnalysisResultResponse = z.infer<
  typeof api.ai.analyzeResume.responses[200]
>;
