## Packages
(none needed)

## Notes
Uses existing shadcn/ui components already in repo.
Assumes backend sets createdAt as ISO string; frontend coerces to Date with z.coerce.date() when parsing.
All API calls include credentials: "include".
