import { ReactNode, useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  BarChart3,
  FilePlus2,
  Moon,
  SunMedium,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

type NavItem = {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  testId: string;
};

function useTheme() {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    if (typeof window === "undefined") return "light";
    return document.documentElement.classList.contains("dark") ? "dark" : "light";
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  return { theme, setTheme, toggle: () => setTheme((t) => (t === "dark" ? "light" : "dark")) };
}

export default function AppShell({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: ReactNode;
}) {
  const [location] = useLocation();
  const theme = useTheme();

  const nav: NavItem[] = useMemo(
    () => [
      { href: "/", label: "Dashboard", icon: BarChart3, testId: "nav-dashboard" },
      { href: "/new", label: "New analysis", icon: FilePlus2, testId: "nav-new-analysis" },
    ],
    [],
  );

  useEffect(() => {
    document.title = title;
    const meta =
      document.querySelector('meta[name="description"]') ||
      (() => {
        const m = document.createElement("meta");
        m.setAttribute("name", "description");
        document.head.appendChild(m);
        return m;
      })();
    meta.setAttribute("content", description);
  }, [title, description]);

  return (
    <div className="min-h-screen surface-grid">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-[280px,1fr] gap-6 lg:gap-10">
          {/* Sidebar */}
          <aside className="grain rounded-3xl border bg-sidebar/70 backdrop-blur-xl elevate-card overflow-hidden">
            <div className="p-5">
              <div className="flex items-center gap-3">
                <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-primary/18 via-accent/14 to-transparent border border-border flex items-center justify-center shadow-sm">
                  <Sparkles className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <div className="font-display text-lg leading-tight">
                    Resume Lens
                  </div>
                  <div className="text-sm text-muted-foreground leading-tight">
                    Recruiter-grade AI insights
                  </div>
                </div>
              </div>

              <div className="mt-5 flex items-center gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={theme.toggle}
                  className="w-full justify-between rounded-2xl ring-focus hover:shadow-sm transition-all"
                  data-testid="toggle-theme"
                >
                  <span className="flex items-center gap-2">
                    {theme.theme === "dark" ? (
                      <Moon className="h-4 w-4" />
                    ) : (
                      <SunMedium className="h-4 w-4" />
                    )}
                    Theme
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {theme.theme === "dark" ? "Dark" : "Light"}
                  </span>
                </Button>
              </div>

              <Separator className="my-5" />

              <nav className="space-y-1">
                {nav.map((item) => {
                  const active =
                    item.href === "/"
                      ? location === "/"
                      : location.startsWith(item.href);

                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "group flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-medium transition-all duration-200",
                        "ring-focus focus-visible:ring-offset-0",
                        active
                          ? "bg-gradient-to-r from-primary/14 to-accent/10 border border-border shadow-sm"
                          : "hover:bg-muted/60 border border-transparent",
                      )}
                      data-testid={item.testId}
                    >
                      <span
                        className={cn(
                          "h-9 w-9 rounded-xl flex items-center justify-center border transition-all",
                          active
                            ? "bg-primary/10 border-primary/20 text-primary"
                            : "bg-background/60 border-border text-muted-foreground group-hover:text-foreground",
                        )}
                      >
                        <Icon className="h-4 w-4" />
                      </span>
                      <span className="truncate">{item.label}</span>
                      <span
                        className={cn(
                          "ml-auto h-1.5 w-1.5 rounded-full transition-opacity",
                          active ? "opacity-100 bg-primary" : "opacity-0 bg-primary",
                        )}
                        aria-hidden="true"
                      />
                    </Link>
                  );
                })}
              </nav>

              <div className="mt-6 rounded-2xl border bg-gradient-to-br from-muted/60 to-background/70 p-4 shadow-sm">
                <div className="text-sm font-semibold">Tip</div>
                <div className="mt-1 text-sm text-muted-foreground leading-relaxed">
                  Paste the job description to unlock keyword coverage & ATS alignment.
                </div>
              </div>
            </div>
          </aside>

          {/* Main */}
          <main className="animate-float-in">
            <div className="grain rounded-3xl border bg-card/70 backdrop-blur-xl elevate-card overflow-hidden">
              <div className="p-5 sm:p-7 lg:p-8">{children}</div>
            </div>

            <footer className="mt-6 text-xs text-muted-foreground flex items-center justify-between px-1">
              <span>Built for clarity. Designed for hiring velocity.</span>
              <span className="hidden sm:inline">© {new Date().getFullYear()} Resume Lens</span>
            </footer>
          </main>
        </div>
      </div>
    </div>
  );
}
