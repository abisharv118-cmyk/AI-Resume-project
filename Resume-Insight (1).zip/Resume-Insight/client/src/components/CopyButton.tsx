import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function CopyButton({
  text,
  label = "Copy",
  variant = "secondary",
  size = "sm",
  "data-testid": dataTestId,
}: {
  text: string;
  label?: string;
  variant?: "default" | "secondary" | "outline" | "ghost" | "destructive";
  size?: "default" | "sm" | "lg" | "icon";
  "data-testid"?: string;
}) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      onClick={async () => {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        toast({ title: "Copied", description: "Copied to clipboard." });
        window.setTimeout(() => setCopied(false), 1100);
      }}
      className="rounded-2xl ring-focus transition-all hover:-translate-y-0.5 hover:shadow-md active:translate-y-0"
      data-testid={dataTestId}
    >
      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      <span className="ml-2">{copied ? "Copied" : label}</span>
    </Button>
  );
}
