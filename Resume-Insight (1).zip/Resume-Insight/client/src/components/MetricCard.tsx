import { ReactNode } from "react";
import { cn } from "@/lib/utils";

export default function MetricCard({
  label,
  value,
  hint,
  icon,
  tone = "primary",
  "data-testid": dataTestId,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  icon: ReactNode;
  tone?: "primary" | "accent" | "muted";
  "data-testid"?: string;
}) {
  const toneClasses =
    tone === "primary"
      ? "from-primary/18 via-primary/10 to-transparent border-primary/15"
      : tone === "accent"
        ? "from-accent/18 via-accent/10 to-transparent border-accent/15"
        : "from-muted/80 via-muted/40 to-transparent border-border";

  return (
    <div
      className={cn(
        "grain rounded-3xl border bg-gradient-to-br p-5 shadow-sm",
        toneClasses,
      )}
      data-testid={dataTestId}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-1 font-display text-2xl sm:text-3xl leading-none">
            {value}
          </div>
          {hint ? (
            <div className="mt-2 text-sm text-muted-foreground leading-relaxed">
              {hint}
            </div>
          ) : null}
        </div>
        <div className="h-11 w-11 rounded-2xl bg-background/60 border border-border shadow-sm flex items-center justify-center">
          {icon}
        </div>
      </div>
    </div>
  );
}
