import { AlertTriangle, BadgeCheck, BookOpen, Flag, Hash, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import CopyButton from "@/components/CopyButton";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { ResumeAnalysisResult } from "@shared/schema";

function Block({
  title,
  icon,
  children,
  actions,
  "data-testid": dataTestId,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  actions?: React.ReactNode;
  "data-testid"?: string;
}) {
  return (
    <section
      className="grain rounded-3xl border bg-card/60 shadow-sm overflow-hidden"
      data-testid={dataTestId}
    >
      <div className="p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-10 w-10 rounded-2xl border bg-gradient-to-br from-muted/70 to-background/60 flex items-center justify-center shadow-sm">
              {icon}
            </div>
            <div className="min-w-0">
              <h3 className="font-display text-lg leading-tight truncate">{title}</h3>
            </div>
          </div>
          {actions ? <div className="shrink-0">{actions}</div> : null}
        </div>
        <Separator className="my-4" />
        <div className="text-sm text-foreground/90 leading-relaxed">{children}</div>
      </div>
    </section>
  );
}

export default function AnalysisResultBlocks({
  result,
}: {
  result: ResumeAnalysisResult;
}) {
  const summaryText = result.summary ?? "";
  const strengthsText = (result.strengths ?? []).map((s) => `• ${s}`).join("\n");
  const gapsText = (result.gaps ?? []).map((s) => `• ${s}`).join("\n");
  const keywordsText = (result.atsKeywords ?? []).join(", ");
  const redFlagsText = (result.redFlags ?? []).map((s) => `• ${s}`).join("\n");

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:gap-6">
      <Block
        title="Summary"
        icon={<BookOpen className="h-5 w-5 text-primary" />}
        actions={
          <CopyButton
            text={summaryText}
            label="Copy"
            data-testid="copy-summary"
          />
        }
        data-testid="result-summary"
      >
        <p className="whitespace-pre-wrap">{summaryText || "—"}</p>
      </Block>

      <Block
        title="Strengths"
        icon={<BadgeCheck className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />}
        actions={
          <CopyButton
            text={strengthsText}
            label="Copy"
            data-testid="copy-strengths"
          />
        }
        data-testid="result-strengths"
      >
        {result.strengths?.length ? (
          <ul className="space-y-2">
            {result.strengths.map((s, i) => (
              <li key={i} className="flex gap-3">
                <span className="mt-2 h-1.5 w-1.5 rounded-full bg-emerald-500/70 shrink-0" />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground">No strengths returned.</p>
        )}
      </Block>

      <Block
        title="Gaps to close"
        icon={<Flag className="h-5 w-5 text-amber-600 dark:text-amber-400" />}
        actions={
          <CopyButton text={gapsText} label="Copy" data-testid="copy-gaps" />
        }
        data-testid="result-gaps"
      >
        {result.gaps?.length ? (
          <ul className="space-y-2">
            {result.gaps.map((s, i) => (
              <li key={i} className="flex gap-3">
                <span className="mt-2 h-1.5 w-1.5 rounded-full bg-amber-500/70 shrink-0" />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground">No gaps returned.</p>
        )}
      </Block>

      <Block
        title="ATS Keywords"
        icon={<Hash className="h-5 w-5 text-accent" />}
        actions={
          <CopyButton
            text={keywordsText}
            label="Copy"
            data-testid="copy-ats-keywords"
          />
        }
        data-testid="result-ats-keywords"
      >
        {result.atsKeywords?.length ? (
          <div className="flex flex-wrap gap-2">
            {result.atsKeywords.map((k, i) => (
              <Badge
                key={`${k}-${i}`}
                className={cn(
                  "rounded-2xl px-3 py-1 text-xs font-semibold",
                  "bg-gradient-to-br from-accent/14 to-primary/10 text-foreground border border-border",
                )}
                data-testid={`ats-keyword-${i}`}
              >
                {k}
              </Badge>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">No keywords returned.</p>
        )}
      </Block>

      <section
        className="lg:col-span-2 grain rounded-3xl border bg-gradient-to-br from-primary/8 via-card/70 to-accent/6 shadow-sm overflow-hidden"
        data-testid="result-rewrite-suggestions"
      >
        <div className="p-5 sm:p-6">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="h-10 w-10 rounded-2xl border bg-background/60 flex items-center justify-center shadow-sm">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <h3 className="font-display text-lg leading-tight truncate">
                  Rewrite Suggestions
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Copy/paste-ready improvements with reasoning.
                </p>
              </div>
            </div>
            <CopyButton
              text={(result.rewriteSuggestions ?? [])
                .map((r) => {
                  const before = r.before ? `Before: ${r.before}\n` : "";
                  return `Section: ${r.section}\n${before}After: ${r.after}\nReason: ${r.reason}\n`;
                })
                .join("\n")}
              label="Copy all"
              data-testid="copy-rewrite-all"
            />
          </div>

          <Separator className="my-4" />

          {result.rewriteSuggestions?.length ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {result.rewriteSuggestions.map((r, idx) => (
                <div
                  key={idx}
                  className="rounded-3xl border bg-card/60 p-4 shadow-sm"
                  data-testid={`rewrite-${idx}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-xs text-muted-foreground">Section</div>
                      <div className="font-semibold truncate">{r.section}</div>
                    </div>
                    <CopyButton
                      text={r.after}
                      label="Copy"
                      data-testid={`copy-rewrite-${idx}`}
                      variant="outline"
                    />
                  </div>

                  {r.before ? (
                    <div className="mt-3">
                      <div className="text-xs font-semibold text-muted-foreground">Before</div>
                      <div className="mt-1 rounded-2xl border bg-muted/40 p-3 text-sm leading-relaxed whitespace-pre-wrap">
                        {r.before}
                      </div>
                    </div>
                  ) : null}

                  <div className="mt-3">
                    <div className="text-xs font-semibold text-muted-foreground">After</div>
                    <div className="mt-1 rounded-2xl border bg-gradient-to-br from-primary/10 to-accent/8 p-3 text-sm leading-relaxed whitespace-pre-wrap">
                      {r.after}
                    </div>
                  </div>

                  <div className="mt-3">
                    <div className="text-xs font-semibold text-muted-foreground">Why</div>
                    <p className="mt-1 text-sm text-foreground/90 leading-relaxed">
                      {r.reason}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No rewrite suggestions returned.</p>
          )}
        </div>
      </section>

      <Block
        title="Red flags"
        icon={<AlertTriangle className="h-5 w-5 text-rose-600 dark:text-rose-400" />}
        actions={
          <CopyButton text={redFlagsText} label="Copy" data-testid="copy-red-flags" />
        }
        data-testid="result-red-flags"
      >
        {result.redFlags?.length ? (
          <ul className="space-y-2">
            {result.redFlags.map((s, i) => (
              <li key={i} className="flex gap-3">
                <span className="mt-2 h-1.5 w-1.5 rounded-full bg-rose-500/70 shrink-0" />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground">No red flags detected.</p>
        )}
      </Block>
    </div>
  );
}
