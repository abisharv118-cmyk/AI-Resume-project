import { cn } from "@/lib/utils";

function clamp(n: number) {
  return Math.max(0, Math.min(100, n));
}

export default function ScoreBadge({
  score,
  size = "md",
  "data-testid": dataTestId,
}: {
  score: number;
  size?: "sm" | "md" | "lg";
  "data-testid"?: string;
}) {
  const s = clamp(score);
  const bucket =
    s >= 85 ? "excellent" : s >= 70 ? "strong" : s >= 50 ? "needs-work" : "risk";

  const palette =
    bucket === "excellent"
      ? "from-emerald-500/18 via-primary/12 to-transparent border-emerald-500/20 text-emerald-700 dark:text-emerald-300"
      : bucket === "strong"
        ? "from-primary/20 via-primary/10 to-transparent border-primary/20 text-primary"
        : bucket === "needs-work"
          ? "from-amber-500/18 via-amber-400/10 to-transparent border-amber-500/20 text-amber-700 dark:text-amber-300"
          : "from-rose-500/18 via-rose-500/10 to-transparent border-rose-500/20 text-rose-700 dark:text-rose-300";

  const sizing =
    size === "sm"
      ? "px-2.5 py-1 text-xs rounded-xl"
      : size === "lg"
        ? "px-4 py-2 text-sm rounded-2xl"
        : "px-3 py-1.5 text-sm rounded-2xl";

  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 border bg-gradient-to-br shadow-sm",
        "backdrop-blur-xl",
        sizing,
        palette,
      )}
      data-testid={dataTestId}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      <span className="font-semibold">{s}</span>
      <span className="text-muted-foreground dark:text-muted-foreground">/100</span>
    </span>
  );
}
