import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type {
  CreateResumeAnalysisRequest,
  ResumeAnalysisResponse,
} from "@shared/schema";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

/**
 * Backend returns createdAt as JSON string; coerce to Date on the client.
 * Also keep `result` validated.
 */
const resumeAnalysisResponseSchema = z.object({
  id: z.number(),
  name: z.string(),
  targetRole: z.string().nullable(),
  resumeText: z.string(),
  jobDescription: z.string().nullable(),
  result: api.ai.analyzeResume.responses[200],
  createdAt: z.coerce.date(),
});

const resumeAnalysesListSchema = z.array(resumeAnalysisResponseSchema);

export function useResumeAnalyses() {
  return useQuery({
    queryKey: [api.resumeAnalyses.list.path],
    queryFn: async () => {
      const res = await fetch(api.resumeAnalyses.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch resume analyses");
      const raw = await res.json();
      // validate list payload from server
      // (we intentionally do NOT use api.resumeAnalyses.list.responses[200] because it can't coerce Date)
      return parseWithLogging(resumeAnalysesListSchema, raw, "resumeAnalyses.list");
    },
  });
}

export function useResumeAnalysis(id: number) {
  return useQuery({
    queryKey: [api.resumeAnalyses.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.resumeAnalyses.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch resume analysis");
      const raw = await res.json();
      return parseWithLogging(resumeAnalysisResponseSchema, raw, "resumeAnalyses.get");
    },
    enabled: Number.isFinite(id),
  });
}

export function useCreateResumeAnalysis() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: CreateResumeAnalysisRequest & { result: unknown }) => {
      // Route manifest input does not include `result`. Backend likely expects it anyway.
      // We validate the common fields via schema; `result` is validated on response.
      const { name, targetRole, resumeText, jobDescription, result } = payload;

      const validated = api.resumeAnalyses.create.input.parse({
        name,
        targetRole,
        resumeText,
        jobDescription,
      });

      const res = await fetch(api.resumeAnalyses.create.path, {
        method: api.resumeAnalyses.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...validated, result }),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const err = api.resumeAnalyses.create.responses[400].safeParse(await res.json());
          if (err.success) throw new Error(err.data.message);
        }
        throw new Error("Failed to create analysis");
      }

      const raw = await res.json();
      return parseWithLogging(resumeAnalysisResponseSchema, raw, "resumeAnalyses.create");
    },
    onSuccess: async (created) => {
      await queryClient.invalidateQueries({ queryKey: [api.resumeAnalyses.list.path] });
      queryClient.setQueryData([api.resumeAnalyses.get.path, created.id], created);
    },
  });
}

export function useDeleteResumeAnalysis() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.resumeAnalyses.delete.path, { id });
      const res = await fetch(url, {
        method: api.resumeAnalyses.delete.method,
        credentials: "include",
      });
      if (res.status === 404) {
        const errRaw = await res.json().catch(() => null);
        const parsed = api.resumeAnalyses.delete.responses[404].safeParse(errRaw);
        if (parsed.success) throw new Error(parsed.data.message);
        throw new Error("Analysis not found");
      }
      if (!res.ok) throw new Error("Failed to delete analysis");
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: [api.resumeAnalyses.list.path] });
    },
  });
}

/** Direct AI analysis (does not persist). */
export function useAnalyzeResume() {
  return useMutation({
    mutationFn: async (input: CreateResumeAnalysisRequest) => {
      const validated = api.ai.analyzeResume.input.parse(input);
      const res = await fetch(api.ai.analyzeResume.path, {
        method: api.ai.analyzeResume.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const err = api.ai.analyzeResume.responses[400].safeParse(await res.json());
          if (err.success) throw new Error(err.data.message);
        }
        throw new Error("Failed to analyze resume");
      }

      return parseWithLogging(api.ai.analyzeResume.responses[200], await res.json(), "ai.analyzeResume");
    },
  });
}

export type ResumeAnalysisClient = ResumeAnalysisResponse & { createdAt: Date };
