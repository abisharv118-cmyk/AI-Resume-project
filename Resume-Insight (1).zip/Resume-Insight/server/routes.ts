import type { Express } from "express";
import type { Server } from "http";
import OpenAI from "openai";
import { z } from "zod";
import { api } from "@shared/routes";
import {
  resumeAnalysisResultSchema,
  type CreateResumeAnalysisRequest,
} from "@shared/schema";
import { storage } from "./storage";

function createOpenAIClient() {
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;

  if (!baseURL || !apiKey) {
    return null;
  }

  return new OpenAI({ apiKey, baseURL });
}

function getZodError(err: z.ZodError) {
  return {
    message: err.errors[0]?.message ?? "Invalid input",
    field: err.errors[0]?.path?.join(".") || undefined,
  };
}

async function analyzeResumeWithAI(input: CreateResumeAnalysisRequest) {
  const system =
    "You are an expert resume reviewer and ATS specialist. " +
    "Return ONLY valid JSON matching the required schema. " +
    "Be specific, practical, and avoid generic advice.";

  const user = {
    name: input.name,
    targetRole: input.targetRole ?? null,
    resumeText: input.resumeText,
    jobDescription: input.jobDescription ?? null,
  };

  const schemaJson = {
    type: "object",
    additionalProperties: false,
    properties: {
      overallScore: { type: "number" },
      summary: { type: "string" },
      strengths: { type: "array", items: { type: "string" } },
      gaps: { type: "array", items: { type: "string" } },
      atsKeywords: { type: "array", items: { type: "string" } },
      rewriteSuggestions: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            section: { type: "string" },
            before: { type: "string" },
            after: { type: "string" },
            reason: { type: "string" },
          },
          required: ["section", "after", "reason"],
        },
      },
      redFlags: { type: "array", items: { type: "string" } },
    },
    required: [
      "overallScore",
      "summary",
      "strengths",
      "gaps",
      "atsKeywords",
      "rewriteSuggestions",
      "redFlags",
    ],
  };

  const client = createOpenAIClient();
  if (!client) {
    throw new Error(
      "AI is not configured yet. Please try again in a moment.",
    );
  }

  const resp = await client.chat.completions.create({
    model: "gpt-5.2",
    messages: [
      { role: "system", content: system },
      {
        role: "user",
        content:
          "Analyze this resume against the target role (and job description if provided). " +
          "Score 0-100 and return structured feedback.\n\n" +
          JSON.stringify(user),
      },
      {
        role: "user",
        content:
          "JSON schema (must match exactly, no extra keys):\n" +
          JSON.stringify(schemaJson),
      },
    ],
    response_format: { type: "json_schema", json_schema: schemaJson as any },
    max_completion_tokens: 1800,
  });

  const content = resp.choices[0]?.message?.content ?? "{}";
  const parsed = JSON.parse(content);
  return resumeAnalysisResultSchema.parse(parsed);
}

async function seedDatabase() {
  const existing = await storage.listResumeAnalyses();
  if (existing.length > 0) return;

  const demoResult = resumeAnalysisResultSchema.parse({
    overallScore: 72,
    summary:
      "Solid junior profile with clear React/TypeScript exposure. Biggest improvements: add measurable impact, clarify scope of projects, and align keywords to the target role.",
    strengths: [
      "Relevant frontend stack (React, TypeScript)",
      "Project-based experience and collaboration mention",
      "Clean, readable structure",
    ],
    gaps: [
      "Missing measurable outcomes (performance, users, conversion, time saved)",
      "No testing or accessibility examples",
      "Projects lack links, scale, and technical depth details",
    ],
    atsKeywords: [
      "React",
      "TypeScript",
      "REST APIs",
      "Accessibility",
      "Testing",
      "Responsive design",
      "State management",
      "Git",
    ],
    rewriteSuggestions: [
      {
        section: "Experience",
        after:
          "Built a responsive e-commerce UI in React + TypeScript, integrating product listing and cart flows; improved Lighthouse performance score by X points by optimizing rendering and assets.",
        reason:
          "Adds scope + impact, and includes keywords recruiters search for.",
      },
      {
        section: "Projects",
        after:
          "Task Tracker (React, TypeScript): Implemented CRUD with form validation, optimistic UI updates, and reusable components; added basic accessibility (labels, focus states) and smoke tests.",
        reason:
          "Demonstrates practical skills (forms, state, accessibility, testing).",
      },
    ],
    redFlags: [
      "Very few concrete metrics",
      "Skills list is short compared to role requirements",
    ],
  });

  await storage.createResumeAnalysis({
    name: "Sample Candidate",
    targetRole: "Junior Frontend Developer",
    resumeText:
      "Summary: Self-taught developer with React experience.\n\nExperience:\n- Built a small e-commerce UI in React and TypeScript\n- Collaborated with a designer to implement responsive layouts\n\nSkills: React, TypeScript, HTML, CSS, Git\n\nProjects:\n- Portfolio site with light/dark mode\n- Task tracker with CRUD",
    jobDescription:
      "Looking for a junior frontend developer with React/TypeScript, basic testing, and accessibility knowledge. Experience with REST APIs and state management is a plus.",
    result: demoResult,
  });
}

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  app.get(api.resumeAnalyses.list.path, async (req, res) => {
    const rows = await storage.listResumeAnalyses();
    res.json(rows);
  });

  app.get(api.resumeAnalyses.get.path, async (req, res) => {
    const id = Number(req.params.id);
    const row = await storage.getResumeAnalysis(id);
    if (!row) return res.status(404).json({ message: "Not found" });
    res.json(row);
  });

  app.post(api.ai.analyzeResume.path, async (req, res) => {
    try {
      const input = api.ai.analyzeResume.input.parse(req.body);
      const result = await analyzeResumeWithAI(input);
      res.json(result);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(getZodError(err));
      }
      throw err;
    }
  });

  app.post(api.resumeAnalyses.create.path, async (req, res) => {
    try {
      const input = api.resumeAnalyses.create.input.parse(req.body);
      const body = req.body as any;
      const result = resumeAnalysisResultSchema.parse(body.result);

      const created = await storage.createResumeAnalysis({
        name: input.name,
        targetRole: input.targetRole,
        resumeText: input.resumeText,
        jobDescription: input.jobDescription,
        result,
      });

      res.status(201).json(created);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(getZodError(err));
      }
      throw err;
    }
  });

  app.delete(api.resumeAnalyses.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    const row = await storage.getResumeAnalysis(id);
    if (!row) return res.status(404).json({ message: "Not found" });
    await storage.deleteResumeAnalysis(id);
    res.status(204).send();
  });

  await seedDatabase();

  return httpServer;
}
