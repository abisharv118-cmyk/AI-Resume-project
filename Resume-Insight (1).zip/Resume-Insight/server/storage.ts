import { db } from "./db";
import {
  resumeAnalyses,
  type CreateResumeAnalysisRequest,
  type ResumeAnalysisResponse,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  listResumeAnalyses(): Promise<ResumeAnalysisResponse[]>;
  getResumeAnalysis(id: number): Promise<ResumeAnalysisResponse | undefined>;
  createResumeAnalysis(input: {
    name: string;
    targetRole?: string;
    resumeText: string;
    jobDescription?: string;
    result: unknown;
  }): Promise<ResumeAnalysisResponse>;
  deleteResumeAnalysis(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async listResumeAnalyses(): Promise<ResumeAnalysisResponse[]> {
    const rows = await db
      .select()
      .from(resumeAnalyses)
      .orderBy(desc(resumeAnalyses.createdAt));

    return rows as unknown as ResumeAnalysisResponse[];
  }

  async getResumeAnalysis(id: number): Promise<ResumeAnalysisResponse | undefined> {
    const [row] = await db
      .select()
      .from(resumeAnalyses)
      .where(eq(resumeAnalyses.id, id));

    return row as unknown as ResumeAnalysisResponse | undefined;
  }

  async createResumeAnalysis(input: {
    name: string;
    targetRole?: string;
    resumeText: string;
    jobDescription?: string;
    result: unknown;
  }): Promise<ResumeAnalysisResponse> {
    const [created] = await db
      .insert(resumeAnalyses)
      .values({
        name: input.name,
        targetRole: input.targetRole ?? null,
        resumeText: input.resumeText,
        jobDescription: input.jobDescription ?? null,
        result: input.result,
      })
      .returning();

    return created as unknown as ResumeAnalysisResponse;
  }

  async deleteResumeAnalysis(id: number): Promise<void> {
    await db.delete(resumeAnalyses).where(eq(resumeAnalyses.id, id));
  }
}

export const storage = new DatabaseStorage();
